export class MenuItem {
  title: string;
  path: string;
  subMenu: MenuItem[];
}
